package trabalho_3;
import java.io.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import manipulacao_arquivo.Pokemon;
import trabalho_1.CRUD;
import trabalho_2.Indexacao;
import java.io.RandomAccessFile;
import manipulacao_arquivo.Pokemon;



 /* 1- Mudar o crud (case 8)
            case 8:
            String palavra_busca;

            System.out.print("Digite a palavra para o casamento de padrões: ");
            String palavra_busca = scanner.next();
                            
            casamento.busca(palavra_busca, caminho_arq_csv);


     
    */


public class casamento {

    public static int[]CriarTabelaPrefixo(String padrao) {
            int[] tabelaprefixo = new int[padrao.length()];
            int i = 0;
    
            for (int j = 1; j < padrao.length(); j++) {
                if (padrao.charAt(i) == padrao.charAt(j)) {
                    i++;
                    tabelaprefixo[j] = i;
                } else {
                    if (i != 0) {
                        i = tabelaprefixo[i - 1];
                        j--;
                    } else {
                        tabelaprefixo[j] = 0;
                    }
                }
            }
    
            return tabelaprefixo;
        }
    

    public static List<Integer> kmpBusca(String texto, String padrao) {
            List<Integer> matches = new ArrayList<>();
            int[] tabelaprfixo = CriarTabelaPrefixo (padrao);
            int i = 0, j = 0;
    
            while (i < texto.length()) {
                if (texto.charAt(i) == padrao.charAt(j)) {
                    i++;
                    j++;
    
                    if (j == padrao.length()) {
                        matches.add(i - j);
                        j = tabelaprfixo[j - 1];
                    }
                } else {
                    if (j != 0) {
                        j = tabelaprfixo[j - 1];
                    } else {
                        i++;
                    }
                }
            }
    
            return matches;
        }
   
    
    public static void busca(String palavra, RandomAccessFile inputFile, CRUD crud) throws Exception {
        
        Pokemon poke;
        int id=0;
        
        

        while (inputFile.getFilePointer()<inputFile.length()) {

            poke=new Pokemon();
            poke = crud.ler(id);
            String partes[];
            partes= poke.palavras_por_partes();

            id++;

            for(int i=0;i<partes.length;i++){
                String texto = partes[i];
                List<Integer> matches = kmpBusca(texto, palavra);
                if (!matches.isEmpty()) {
                    System.out.println("Padrão encontrado nas posições: " + matches);
                    System.out.println("ID do objeto: " + id);
                }

            }

           
        }

        

    }
}
    

